package com.example.toast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.muddzdev.styleabletoast.StyleableToast;

import es.dmoral.toasty.Toasty;

public class MainActivity extends AppCompatActivity {
    // basic toast
    Button basictoast;
    // gravity toast
    Button gravitytoast;
    // custom toast
    Button customtoast;
    // styleable toast
    Button styleabletoast;
    Button errotoast,sucesstoast,warningtoast,icontoast,infotoast;
    Toast toast;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        basictoast = findViewById(R.id.basictoast);
        gravitytoast = findViewById(R.id.gravitytoast);
        customtoast = findViewById(R.id.customtoast);
        styleabletoast = findViewById(R.id.stytoast);
        errotoast = findViewById(R.id.errortoast);
        sucesstoast = findViewById(R.id.sucesstoast);
        warningtoast = findViewById(R.id.warningtoast);
        icontoast = findViewById(R.id.icontoast);
        infotoast = findViewById(R.id.infotoast);

    }

    public void displayToast(View view){
            switch(view.getId()){
                case R.id.basictoast:
                    toast = Toast.makeText(getApplicationContext(),"Basic Toast",Toast.LENGTH_LONG);
                    toast.show();
                    break;
                case R.id.gravitytoast:
                    toast = Toast.makeText(getApplicationContext(),"Basic Toast",Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL,0,0);
                    toast.show();
                    break;
                case R.id.customtoast:
                    LayoutInflater layoutInflater = getLayoutInflater();
                    View v = layoutInflater.inflate(R.layout.custom,(ViewGroup) findViewById(R.id.custom_layout));
                    toast = new Toast(getApplicationContext());
                    toast.setGravity(Gravity.BOTTOM,0,0);
                    toast.setDuration(Toast.LENGTH_LONG);
                    toast.setView(v);
                    toast.show();
                    break;
                case R.id.stytoast:
                    StyleableToast.makeText(getApplicationContext(),"Styleable text",Toast.LENGTH_LONG,R.style.mytoast).show();
                    break;
                case R.id.errortoast:
                    Toasty.error(getApplicationContext(), "This is an error toast.", Toast.LENGTH_SHORT, true).show();
                    break;
                case R.id.sucesstoast:
                    Toasty.success(getApplicationContext(), "Success!", Toast.LENGTH_SHORT, true).show();
                    break;
                case R.id.warningtoast:
                    Toasty.warning(getApplicationContext(), "Warning..", Toast.LENGTH_SHORT, true).show();
                    break;
                case R.id.infotoast:
                    Toasty.info(getApplicationContext(), "Here is some info for you.", Toast.LENGTH_SHORT, true).show();
                    break;
                case R.id.icontoast:
                    Toasty.normal(getApplicationContext(), "Normal toast w/o icon").show();
                    break;

                    // there are more examples user can check the link "https://github.com/GrenderG/Toasty"

            }
    }


}